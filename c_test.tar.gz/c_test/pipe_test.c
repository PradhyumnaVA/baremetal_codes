#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main(){
	int i,j;
	int pipefd[2]; // this holds the read and write fd
	char usr_input;
	char buffer[1];
	
	// creating pipe
	if(pipe(pipefd) == -1){
		perror("pipe not created");
		exit(EXIT_FAILURE);
	}

	// creating child 
	pid_t pid = fork();
	if(pid == 0){
		//child process
		while(1){
			close(pipefd[0]); // closing read end of pipe
			usr_input = getchar();
			char *write_byte = &usr_input; // the input to write needs to be pointer, so user input is turned into pointer
			write(pipefd[1], write_byte, 1); // write 1 byte of data that is entered 
			printf("child sent: %c\n",usr_input);
			fflush(stdout);
			if(usr_input == 'q'){
				exit(1); // ends the child process, so that it doesnt become zombie
				break; // ends the infinite loop
			}
		}
	}
	else {
	 	//parent process
		while(1){
			close(pipefd[1]); // closing write end of pipe
			read(pipefd[0], buffer, sizeof(buffer)); // reading from the buffer, read internally clears the buffer
			printf("parent received: %s\n", buffer);
			fflush(stdout);
			if(buffer[0] == 'q'){
				wait(NULL); // waits until the child process is terminated to end the parent process, so that orphan is not created
				break; // ends the infinite loop
			}
		}
	}
	return 0;
}
